/**++
 *   
 *   LICENSE
 *   -------
 *   
 *   Copyright (c) 2004 Renato Mancuso
 *   All rights reserved.
 *   
 *   Redistribution and use in source and binary forms, with or without modification, are 
 *   permitted provided that the following conditions are met:
 *   
 *   - Redistributions of source code must retain the above copyright notice, this list 
 *     of conditions and the following disclaimer.
 *   
 *   - Redistributions in binary form must reproduce the above copyright notice, this list
 *     of conditions and the following disclaimer in the documentation and/or other materials 
 *     provided with the distribution.
 *   
 *   - Neither the name of Renato Mancuso nor the names of its contributors may be used to 
 *     endorse or promote products derived from this software without specific prior written 
 *     permission.
 *   
 *   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS AS IS AND ANY EXPRESS 
 *   OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
 *   AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 *   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 *   DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
 *   DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
 *   IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
 *   OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *   
--**/


#include "TextSourceCharIterator.hpp"

#include <cstdio>
#include <cstring>
#include <cassert>

namespace OpenEMBL
{
namespace Phoenix
{

    TextSourceCharIterator::TextSourceCharIterator()
        : m_TextSource(NULL)
        , m_CurrPos(NULL)
        , m_CurrLineEnd(NULL)
    {
    }
    
    void TextSourceCharIterator::setTextSource(ITextSource* theTextSource)
    {
        m_TextSource = theTextSource;

        if (NULL != m_TextSource)
        {
            m_CurrPos = m_TextSource->currentLine();
            
            if (NULL != m_CurrPos)
                m_CurrLineEnd = m_CurrPos + strlen(m_CurrPos);
        }
        else
        {
            m_CurrPos = NULL;
        }
    }

    long TextSourceCharIterator::currentLineNumber() const throw()
    {
        if (NULL != m_TextSource)
            return m_TextSource->currentLineNumber();

        return TEXTSOURCE_INVALID_LINE_NUMBER;
    }

    int TextSourceCharIterator::currentChar() const throw()
    {
        if (NULL == m_CurrPos)
            return EOF;

        if (m_CurrPos == m_CurrLineEnd)
            return '\n';

        return *m_CurrPos;
    }

    void TextSourceCharIterator::nextChar()
    {
        if (NULL == m_CurrPos)
            return;

        if (m_CurrPos < m_CurrLineEnd)
        {
            ++m_CurrPos;
        }
        else
        {
            assert(m_TextSource != NULL);
            assert(m_CurrPos == m_CurrLineEnd);

            m_TextSource->nextLine();
    
            m_CurrPos = m_TextSource->currentLine();
        
            if (NULL != m_CurrPos)
                m_CurrLineEnd = m_CurrPos + strlen(m_CurrPos);
        }
    }

}
}

