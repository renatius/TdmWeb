// $Id: pcre_helpers.h,v 1.1.1.1 2004/03/07 02:24:15 Renato Exp $

#pragma once

#ifdef __cplusplus
    extern "C" {
#endif

// added helpers
extern void* pcre_malloc_ex( size_t n );
extern void pcre_free_ex( void* p );
extern char const* pcre_setlocale( int category, char const* locale );
extern int pcre_major( void );
extern int pcre_minor( void );
extern char const* pcre_date( void );

// callout facility
typedef int ( *PCRE_CALLOUT_CALLBACK )( pcre_callout_block * );

extern PCRE_CALLOUT_CALLBACK pcre_set_callout_handler( PCRE_CALLOUT_CALLBACK handler ); 
extern int pcre_extra_set_match_limit( pcre_extra** extraptr, long value );
extern int pcre_extra_set_callout_data( pcre_extra** extraptr, void* data ); 

#ifdef __cplusplus
    }  /* extern "C" */
#endif
