// $Id: pcre_helpers.c,v 1.1.1.1 2004/03/07 02:24:15 Renato Exp $

#include "internal.h"
#include "pcre_helpers.h"
#include <locale.h>
#include <memory.h>

#define STRING(a)  # a
#define XSTRING(s) STRING(s)

void* pcre_malloc_ex( size_t n )
{
    return pcre_malloc( n );
}

void pcre_free_ex( void* p )
{
    pcre_free( p );
}

char const* pcre_setlocale( int category, char const* locale )
{
    return setlocale( category, locale );
}

int pcre_major( void )
{
    return PCRE_MAJOR;
}

int pcre_minor( void )
{
    return PCRE_MINOR;
}

char const* pcre_date( void )
{
    static char const* sz_date = XSTRING( PCRE_DATE );
    return sz_date;
}

PCRE_CALLOUT_CALLBACK pcre_set_callout_handler( PCRE_CALLOUT_CALLBACK handler ) 
{
    PCRE_CALLOUT_CALLBACK result = pcre_callout;
    pcre_callout = handler;
    return result;
}

static pcre_extra* create_pcre_extra()
{
    pcre_extra* p = ( pcre_extra* ) pcre_malloc( sizeof( pcre_extra ) );

    if ( NULL != p )
        memset( p, 0, sizeof( pcre_extra ) );
    
    return p;
}

int pcre_extra_set_match_limit( pcre_extra** extraptr, long value )
{
    if ( NULL == extraptr )
        return PCRE_ERROR_NULL;

    if ( NULL == *extraptr )
        *extraptr = create_pcre_extra();

    if ( NULL == *extraptr )
        return PCRE_ERROR_NOMEMORY;

    (*extraptr)->flags |= PCRE_EXTRA_MATCH_LIMIT;
    (*extraptr)->match_limit = value;

    return 0;
}

int pcre_extra_set_callout_data( pcre_extra** extraptr, void* data )
{
    if ( NULL == extraptr )
        return PCRE_ERROR_NULL;

    if ( NULL == *extraptr )
        *extraptr = create_pcre_extra();

    if ( NULL == *extraptr )
        return PCRE_ERROR_NOMEMORY;

    (*extraptr)->flags |= PCRE_EXTRA_CALLOUT_DATA;
    (*extraptr)->callout_data = data;

    return 0;
}
