// $Id: pcre_helpers.c,v 1.2 2002/11/14 00:57:52 Renato Mancuso Exp $

#include "pcre_helpers.h"
#include <locale.h>


#define STRING(a)  # a
#define XSTRING(s) STRING(s)

void* pcre_malloc_ex( size_t n )
{
    return pcre_malloc(n);
}

void pcre_free_ex( void* p )
{
    pcre_free(p);
}

char const* pcre_setlocale( int category, char const* locale )
{
    return setlocale( category, locale );
}

int pcre_major( void )
{
    return PCRE_MAJOR;
}

int pcre_minor( void )
{
    return PCRE_MINOR;
}


char const* pcre_date( void )
{
    static char const* sz_date = XSTRING(PCRE_DATE);
    return sz_date;
}


