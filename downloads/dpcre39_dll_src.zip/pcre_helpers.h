// $Id: pcre_helpers.h,v 1.2 2002/11/14 00:57:52 Renato Mancuso Exp $

#pragma once

#include "pcre.h"

#ifdef __cplusplus
    extern "C" {
#endif

// added helpers
extern void* pcre_malloc_ex( size_t n );
extern void pcre_free_ex( void* p );
extern char const* pcre_setlocale( int category, char const* locale );
extern int pcre_major( void );
extern int pcre_minor( void );
extern char const* pcre_date( void );

#ifdef __cplusplus
    }  /* extern "C" */
#endif
