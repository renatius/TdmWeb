-----------------------------------------------------------------
NOTICE
-----------------------------------------------------------------

This zip file contains a compiled custom version of 
PCRE 3.9 and is neither the original NOR a complete 
distribution of PCRE.

To obtain the original PCRE distribution please go to the 
original PCRE FTP site at:

	ftp://ftp.csx.cam.ac.uk/pub/software/programming/pcre/

or visit the pcre.org web site at:

	http://www.pcre.org
	
To obtain the modified sources and the Microsoft 
Visual Studio.NET Solution that have been used to 
build this dll please go to:

	http://www.renatomancuso.com

This custom version contains additional helper functions and has 
been built for the only purpose of demonstrating how to make 
PCRE accessible from Borland Delphi.

***************************************************************
This software is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
***************************************************************

This version is released under the same licensing terms that
apply to the original PCRE distribution. A copy of PCRE original 
licence can be found in the LICENCE file.

Saffron Walden, UK, December 06 2003

Renato Mancuso <mancuso@renatomancuso.com>